import { Prisma } from "@prisma/client";
import { z } from "zod";

/** Format the first zod issue into a human-readable message. */
export function zodErrorMessage(error: z.ZodError): string {
  const issue = error.issues[0];
  if (!issue) return "Invalid request body";
  const path = issue.path.join(".");
  return path ? `${path}: ${issue.message}` : issue.message;
}

/** Safely read a JSON body from a Request. */
export async function readJsonBody(
  req: Request
): Promise<{ ok: true; data: unknown } | { ok: false; error: string }> {
  try {
    return { ok: true, data: await req.json() };
  } catch {
    return { ok: false, error: "Request body must be valid JSON" };
  }
}

/** Prisma P2002 — unique constraint violation. */
export function isUniqueViolation(error: unknown): boolean {
  return error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2002";
}

/** Prisma P2025 — record to update/delete not found. */
export function isRecordNotFound(error: unknown): boolean {
  return error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2025";
}

/** Parse a route param into a positive integer id, or null when invalid. */
export function parseIdParam(raw: string): number | null {
  const n = Number(raw);
  return Number.isInteger(n) && n > 0 ? n : null;
}

/** Remove keys whose value is undefined (so PATCH only touches provided fields). */
export function stripUndefined<T extends Record<string, unknown>>(obj: T): Partial<T> {
  const out: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(obj)) {
    if (value !== undefined) out[key] = value;
  }
  return out as Partial<T>;
}

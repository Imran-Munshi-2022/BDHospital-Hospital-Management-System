import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";

// ---------------------------------------------------------------------------
// Stage constants
// ---------------------------------------------------------------------------

export const STAGES = [
  "REGISTRATION",
  "TRIAGE",
  "CONSULTATION",
  "DIAGNOSTICS",
  "PHARMACY",
  "CHECKOUT",
] as const;

export type StageKey = (typeof STAGES)[number];

export const STAGE_LABELS: Record<StageKey, string> = {
  REGISTRATION: "Registration",
  TRIAGE: "Triage",
  CONSULTATION: "Consultation",
  DIAGNOSTICS: "Diagnostics",
  PHARMACY: "Pharmacy",
  CHECKOUT: "Checkout",
};

/** [base, spread] minutes per stage → deterministic duration is base..base+spread-1 */
const STAGE_DURATIONS: ReadonlyArray<readonly [number, number]> = [
  [3, 3], // REGISTRATION 3-6
  [4, 4], // TRIAGE 4-8
  [6, 6], // CONSULTATION 6-12
  [8, 7], // DIAGNOSTICS 8-15
  [3, 4], // PHARMACY 3-7
  [2, 3], // CHECKOUT 2-5
];

export const PRIORITY_RANK: Record<string, number> = {
  EMERGENCY: 0,
  URGENT: 1,
  NORMAL: 2,
};

export function stageIndex(stage: string): number {
  const idx = STAGES.indexOf(stage as StageKey);
  return idx === -1 ? 0 : idx;
}

/**
 * Deterministic duration (minutes) of a stage for a given tracking record.
 * seed = record.id * 31 + stageIndex → pseudo-random value in [0, 1).
 */
export function stageDuration(recordId: number, idx: number): number {
  const safeIdx = Math.min(Math.max(idx, 0), STAGES.length - 1);
  const [base, spread] = STAGE_DURATIONS[safeIdx];
  const seed = recordId * 31 + safeIdx;
  const pseudo = ((seed * 9301 + 49297) % 233280) / 233280;
  return base + Math.floor(pseudo * spread);
}

// ---------------------------------------------------------------------------
// History / vitals parsing & generation
// ---------------------------------------------------------------------------

export type HistoryEntry = { stage: string; enteredAt: string; durationMin: number };

export function parseHistory(history: string | null): HistoryEntry[] {
  if (!history) return [];
  try {
    const parsed: unknown = JSON.parse(history);
    return Array.isArray(parsed) ? (parsed as HistoryEntry[]) : [];
  } catch {
    return [];
  }
}

export function parseVitals(vitals: string | null): Record<string, unknown> | null {
  if (!vitals) return null;
  try {
    const parsed: unknown = JSON.parse(vitals);
    return typeof parsed === "object" && parsed !== null ? (parsed as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}

/** Deterministic vitals for a patient — generated when a record enters TRIAGE. */
export function generateVitals(patientId: number): string {
  const seed = patientId * 17;
  const pseudo = (n: number): number => (Math.sin(seed + n) * 10000) % 1;
  return JSON.stringify({
    bp: `${110 + Math.floor(Math.abs(pseudo(1)) * 30)}/${70 + Math.floor(Math.abs(pseudo(2)) * 20)}`,
    pulse: 62 + Math.floor(Math.abs(pseudo(3)) * 34),
    temp: (97.8 + Math.abs(pseudo(4)) * 1.6).toFixed(1),
    spo2: 95 + Math.floor(Math.abs(pseudo(5)) * 5),
  });
}

/** Human-readable location of a record's current stage (computed, never stored). */
export function roomForStage(stage: string, recordId: number, doctorId: number | null): string {
  switch (stage) {
    case "REGISTRATION":
      return "Reception Desk";
    case "TRIAGE":
      return `Triage Room ${recordId % 2 === 0 ? "A" : "B"}`;
    case "CONSULTATION":
      return `Cabin ${((doctorId ?? recordId) % 8) + 1}`;
    case "DIAGNOSTICS":
      return recordId % 2 === 0 ? "Pathology Lab" : "Radiology (Imaging)";
    case "PHARMACY":
      return "Pharmacy Counter";
    case "CHECKOUT":
      return "Billing Desk";
    default:
      return "—";
  }
}

// ---------------------------------------------------------------------------
// Live simulation
// ---------------------------------------------------------------------------

/**
 * Advance every ACTIVE tracking record according to elapsed wall-clock time,
 * using per-record deterministic stage durations, and persist the new state.
 * Must run before reading tracking data so the board always reflects "now".
 */
export async function runTrackingSimulation(): Promise<void> {
  const activeRecords = await db.trackingRecord.findMany({ where: { status: "ACTIVE" } });
  const now = Date.now();

  for (const record of activeRecords) {
    let idx = stageIndex(record.currentStage);
    let currentStage: string = STAGES[idx];
    let stageEnteredAtMs = record.stageEnteredAt.getTime();
    let elapsedMin = (now - stageEnteredAtMs) / 60000;
    const history = parseHistory(record.history);
    let vitals = record.vitals;
    let status: string = record.status;
    let changed = false;

    // A record that has already reached TRIAGE (or beyond) must carry vitals.
    if (idx >= 1 && !vitals) {
      vitals = generateVitals(record.patientId);
      changed = true;
    }

    while (elapsedMin >= stageDuration(record.id, idx)) {
      const duration = stageDuration(record.id, idx);
      history.push({
        stage: currentStage,
        enteredAt: new Date(stageEnteredAtMs).toISOString(),
        durationMin: duration,
      });
      stageEnteredAtMs += duration * 60000;
      elapsedMin -= duration;
      idx += 1;
      changed = true;

      if (idx >= STAGES.length) {
        // Past CHECKOUT — the patient has checked out.
        status = "COMPLETED";
        currentStage = "CHECKOUT"; // keep the last stage as the resting value
        break;
      }

      currentStage = STAGES[idx];
      if (idx === 1 && !vitals) {
        // Entering TRIAGE — take vitals if we don't have them yet.
        vitals = generateVitals(record.patientId);
      }
    }

    if (changed) {
      await db.trackingRecord.update({
        where: { id: record.id },
        data: {
          history: JSON.stringify(history),
          currentStage,
          stageEnteredAt: new Date(stageEnteredAtMs),
          ...(vitals !== record.vitals ? { vitals } : {}),
          ...(status !== record.status ? { status } : {}),
        },
      });
    }
  }
}

// ---------------------------------------------------------------------------
// Response shaping
// ---------------------------------------------------------------------------

export const trackingInclude = {
  patient: {
    select: { id: true, fullName: true, gender: true, age: true, bloodGroup: true, phone: true },
  },
  appointment: {
    select: {
      id: true,
      date: true,
      timeSlot: true,
      doctor: {
        select: { id: true, fullName: true, photo: true, specialty: { select: { name: true } } },
      },
    },
  },
} satisfies Prisma.TrackingRecordInclude;

export type TrackingRecordWithRelations = Prisma.TrackingRecordGetPayload<{
  include: typeof trackingInclude;
}>;

/** Total minutes the patient has been in the hospital: completed stages + current elapsed. */
export function computeWaitMinutes(record: {
  history: string | null;
  stageEnteredAt: Date;
  status: string;
}): number {
  const history = parseHistory(record.history);
  const completed = record.status === "COMPLETED";
  const currentElapsedMin = completed
    ? 0
    : Math.max(0, (Date.now() - record.stageEnteredAt.getTime()) / 60000);
  const historySum = history.reduce(
    (sum, entry) =>
      sum + (typeof entry.durationMin === "number" && Number.isFinite(entry.durationMin) ? entry.durationMin : 0),
    0
  );
  return Math.floor(historySum + currentElapsedMin);
}

/**
 * Shape a raw TrackingRecord (with patient + appointment includes) into the
 * rich live-board record consumed by the frontend.
 */
export function shapeTrackingRecord(record: TrackingRecordWithRelations) {
  const history = parseHistory(record.history);
  const vitals = parseVitals(record.vitals);
  const isCompleted = record.status === "COMPLETED";
  const idx = stageIndex(record.currentStage);
  const currentElapsedMin = isCompleted
    ? 0
    : Math.max(0, (Date.now() - record.stageEnteredAt.getTime()) / 60000);
  const currentDuration = stageDuration(record.id, idx);
  const stageProgress = isCompleted
    ? 100
    : Math.min(100, Math.floor((currentElapsedMin / currentDuration) * 100));
  const waitMinutes = computeWaitMinutes(record);
  const room = isCompleted
    ? "—"
    : roomForStage(record.currentStage, record.id, record.appointment?.doctor?.id ?? null);

  const enteredByStage = new Map(history.map((entry) => [entry.stage, entry.enteredAt]));
  const stages = STAGES.map((key, i) => {
    const isCurrent = !isCompleted && i === idx;
    const isDone = isCompleted || i < idx;
    return {
      key,
      label: STAGE_LABELS[key],
      status: isDone ? ("done" as const) : isCurrent ? ("current" as const) : ("pending" as const),
      enteredAt: isCurrent
        ? record.stageEnteredAt.toISOString()
        : (enteredByStage.get(key) ?? null),
    };
  });

  return {
    id: record.id,
    patientId: record.patientId,
    appointmentId: record.appointmentId,
    tokenNumber: record.tokenNumber,
    currentStage: record.currentStage,
    stageEnteredAt: record.stageEnteredAt.toISOString(),
    priority: record.priority,
    room,
    vitals,
    status: record.status,
    history,
    createdAt: record.createdAt.toISOString(),
    updatedAt: record.updatedAt.toISOString(),
    stageProgress,
    waitMinutes,
    stages,
    patient: record.patient,
    appointment: record.appointment,
  };
}

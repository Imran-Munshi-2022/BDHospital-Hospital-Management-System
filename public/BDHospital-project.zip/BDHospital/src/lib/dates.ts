const pad = (n: number): string => String(n).padStart(2, "0");

/** Local calendar date in "YYYY-MM-DD" format (same format Appointment.date uses). */
export function toDateString(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function todayString(): string {
  return toDateString(new Date());
}

/** Local midnight of the given date (defaults to now). */
export function startOfLocalDay(d: Date = new Date()): Date {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}

/** A Date exactly n days in the past (same local time of day). */
export function dateDaysAgo(n: number): Date {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d;
}

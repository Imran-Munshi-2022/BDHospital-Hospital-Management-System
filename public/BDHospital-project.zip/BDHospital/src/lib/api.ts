// BDHospital — typed API client
// Web Engineering Lab CSE416 — Imran Munshi (222-15-6376), Daffodil International University

// ---------------- Types (mirror the backend responses exactly) ----------------

export type Specialty = {
  id: number;
  name: string;
  description: string;
  icon: string;
  doctorCount?: number;
};

export type Doctor = {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  gender: string;
  designation: string;
  specialtyId: number;
  specialty: { id: number; name: string; icon: string };
  bio: string;
  experienceYears: number;
  consultationFee: number;
  rating: number;
  reviewCount: number;
  photo: string;
  isAvailable: boolean;
  createdAt: string;
  _count?: { appointments: number; reviews: number };
};

export type Patient = {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  gender: string;
  age: number;
  bloodGroup: string;
  address: string;
  insuranceId: string | null;
  createdAt: string;
};

export type AppointmentStatus = "SCHEDULED" | "CONFIRMED" | "COMPLETED" | "CANCELLED";

export type Appointment = {
  id: number;
  doctorId: number;
  patientId: number;
  date: string;
  timeSlot: string;
  reason: string;
  status: AppointmentStatus;
  notes: string | null;
  createdAt: string;
  doctor: {
    id: number;
    fullName: string;
    photo: string;
    designation: string;
    specialty: { name: string };
  };
  patient: {
    id: number;
    fullName: string;
    gender: string;
    age: number;
    bloodGroup: string;
  };
};

export type Review = {
  id: number;
  doctorId: number;
  patientId: number;
  rating: number;
  comment: string;
  createdAt: string;
  doctor: { id: number; fullName: string; photo: string };
  patient: { id: number; fullName: string };
};

export type StageKey =
  | "REGISTRATION"
  | "TRIAGE"
  | "CONSULTATION"
  | "DIAGNOSTICS"
  | "PHARMACY"
  | "CHECKOUT";

export type Vitals = { bp: string; pulse: number; temp: string; spo2: number };

export type HistoryEntry = { stage: string; enteredAt: string; durationMin: number };

export type TrackingRecord = {
  id: number;
  patientId: number;
  appointmentId: number | null;
  tokenNumber: string;
  currentStage: StageKey;
  stageEnteredAt: string;
  priority: "NORMAL" | "URGENT" | "EMERGENCY";
  room: string;
  vitals: Vitals | null;
  status: "ACTIVE" | "COMPLETED";
  history: HistoryEntry[];
  createdAt: string;
  updatedAt: string;
  stageProgress: number;
  waitMinutes: number;
  stages: { key: StageKey; label: string; status: "done" | "current" | "pending"; enteredAt: string | null }[];
  patient: {
    id: number;
    fullName: string;
    gender: string;
    age: number;
    bloodGroup: string;
    phone: string;
  };
  appointment: {
    id: number;
    date: string;
    timeSlot: string;
    doctor: { id: number; fullName: string; photo: string; specialty: { name: string } };
  } | null;
};

export type TrackingResponse = {
  serverTime: string;
  records: TrackingRecord[];
  stageCounts: Record<string, number>;
  queue: { active: number; avgWaitMinutes: number; completedToday: number };
};

export type Bed = {
  id: number;
  ward: string;
  bedNumber: string;
  status: "AVAILABLE" | "OCCUPIED" | "CLEANING";
  patientId: number | null;
  patient: { id: number; fullName: string; bloodGroup: string } | null;
};

export type BedsResponse = {
  beds: Bed[];
  wards: { ward: string; total: number; occupied: number; available: number; cleaning: number }[];
};

export type Blog = {
  id: number;
  title: string;
  summary: string;
  content: string;
  category: string;
  coverImage: string;
  authorId: number;
  publishedAt: string;
  views: number;
  author: {
    id: number;
    fullName: string;
    photo: string;
    designation: string;
    specialty: { name: string };
  };
};

export type Stats = {
  doctors: { total: number; available: number };
  patients: { total: number; todayCheckedIn: number };
  appointments: {
    today: number;
    total: number;
    scheduled: number;
    confirmed: number;
    completed: number;
    cancelled: number;
  };
  reviews: { total: number; avgRating: number };
  beds: {
    total: number;
    occupied: number;
    available: number;
    cleaning: number;
    occupancyRate: number;
  };
  appointmentsByDay: { date: string; count: number }[];
  specialtyDistribution: { name: string; count: number }[];
  activeTracking: number;
  avgWaitMinutes: number;
};

// ---------------- Fetch helpers ----------------

async function json<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => null);
  if (!res.ok) {
    const message =
      data && typeof data === "object" && "error" in data
        ? String((data as { error: unknown }).error)
        : `Request failed (${res.status})`;
    throw new Error(message);
  }
  return data as T;
}

const base = "/api";

export async function fetchStats(): Promise<Stats> {
  return json<Stats>(await fetch(`${base}/stats`, { cache: "no-store" }));
}

export async function fetchDoctors(params: { search?: string; specialtyId?: number } = {}): Promise<Doctor[]> {
  const q = new URLSearchParams();
  if (params.search) q.set("search", params.search);
  if (params.specialtyId) q.set("specialtyId", String(params.specialtyId));
  const res = await fetch(`${base}/doctors?${q.toString()}`, { cache: "no-store" });
  return (await json<{ doctors: Doctor[] }>(res)).doctors;
}

export async function fetchDoctor(id: number): Promise<Doctor> {
  return (await json<{ doctor: Doctor }>(await fetch(`${base}/doctors/${id}`, { cache: "no-store" }))).doctor;
}

export async function fetchPatients(search = ""): Promise<Patient[]> {
  const res = await fetch(`${base}/patients${search ? `?search=${encodeURIComponent(search)}` : ""}`, { cache: "no-store" });
  return (await json<{ patients: Patient[] }>(res)).patients;
}

export async function fetchAppointments(params: { status?: string; date?: string; doctorId?: number; patientId?: number } = {}): Promise<Appointment[]> {
  const q = new URLSearchParams();
  if (params.status) q.set("status", params.status);
  if (params.date) q.set("date", params.date);
  if (params.doctorId) q.set("doctorId", String(params.doctorId));
  if (params.patientId) q.set("patientId", String(params.patientId));
  const res = await fetch(`${base}/appointments?${q.toString()}`, { cache: "no-store" });
  return (await json<{ appointments: Appointment[] }>(res)).appointments;
}

export async function fetchReviews(params: { doctorId?: number; patientId?: number } = {}): Promise<Review[]> {
  const q = new URLSearchParams();
  if (params.doctorId) q.set("doctorId", String(params.doctorId));
  if (params.patientId) q.set("patientId", String(params.patientId));
  const res = await fetch(`${base}/reviews?${q.toString()}`, { cache: "no-store" });
  return (await json<{ reviews: Review[] }>(res)).reviews;
}

export async function fetchTracking(): Promise<TrackingResponse> {
  return json<TrackingResponse>(await fetch(`${base}/tracking`, { cache: "no-store" }));
}

export async function fetchBeds(): Promise<BedsResponse> {
  return json<BedsResponse>(await fetch(`${base}/beds`, { cache: "no-store" }));
}

export async function fetchBlogs(): Promise<Blog[]> {
  return (await json<{ blogs: Blog[] }>(await fetch(`${base}/blogs`, { cache: "no-store" }))).blogs;
}

export async function fetchBlog(id: number): Promise<Blog> {
  return (await json<{ blog: Blog }>(await fetch(`${base}/blogs/${id}`, { cache: "no-store" }))).blog;
}

export async function fetchSpecialties(): Promise<Specialty[]> {
  return (await json<{ specialties: Specialty[] }>(await fetch(`${base}/specialties`, { cache: "no-store" }))).specialties;
}

// ---------------- Mutations ----------------

type Body = Record<string, unknown>;

async function mutate<T>(path: string, method: "POST" | "PATCH" | "DELETE", body?: Body): Promise<T> {
  const res = await fetch(`${base}${path}`, {
    method,
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  return json<T>(res);
}

export const createDoctor = (data: Body) => mutate<{ doctor: Doctor }>("/doctors", "POST", data);
export const updateDoctor = (id: number, data: Body) => mutate<{ doctor: Doctor }>(`/doctors/${id}`, "PATCH", data);
export const deleteDoctor = (id: number) => mutate<{ success: boolean }>(`/doctors/${id}`, "DELETE");

export const createPatient = (data: Body) => mutate<{ patient: Patient }>("/patients", "POST", data);
export const updatePatient = (id: number, data: Body) => mutate<{ patient: Patient }>(`/patients/${id}`, "PATCH", data);
export const deletePatient = (id: number) => mutate<{ success: boolean }>(`/patients/${id}`, "DELETE");

export const createAppointment = (data: Body) => mutate<{ appointment: Appointment }>("/appointments", "POST", data);
export const updateAppointment = (id: number, data: Body) => mutate<{ appointment: Appointment }>(`/appointments/${id}`, "PATCH", data);
export const deleteAppointment = (id: number) => mutate<{ success: boolean }>(`/appointments/${id}`, "DELETE");

export const createReview = (data: Body) => mutate<{ review: Review }>("/reviews", "POST", data);
export const deleteReview = (id: number) => mutate<{ success: boolean }>(`/reviews/${id}`, "DELETE");

export const checkInPatient = (data: Body) => mutate<{ record: TrackingRecord }>("/tracking", "POST", data);
export const trackingAction = (id: number, action: "advance" | "complete") =>
  mutate<{ record: TrackingRecord }>(`/tracking/${id}`, "PATCH", { action });

export const updateBed = (id: number, data: Body) => mutate<{ bed: Bed }>(`/beds/${id}`, "PATCH", data);

export const createBlog = (data: Body) => mutate<{ blog: Blog }>("/blogs", "POST", data);
export const deleteBlog = (id: number) => mutate<{ success: boolean }>(`/blogs/${id}`, "DELETE");

// ---------------- Shared constants ----------------

export const STAGE_ORDER: StageKey[] = [
  "REGISTRATION",
  "TRIAGE",
  "CONSULTATION",
  "DIAGNOSTICS",
  "PHARMACY",
  "CHECKOUT",
];

export const STAGE_META: Record<StageKey, { label: string; icon: string; color: string }> = {
  REGISTRATION: { label: "Registration", icon: "ClipboardList", color: "text-sky-700 bg-sky-100 dark:text-sky-300 dark:bg-sky-950" },
  TRIAGE: { label: "Triage & Vitals", icon: "HeartPulse", color: "text-violet-700 bg-violet-100 dark:text-violet-300 dark:bg-violet-950" },
  CONSULTATION: { label: "Consultation", icon: "Stethoscope", color: "text-emerald-700 bg-emerald-100 dark:text-emerald-300 dark:bg-emerald-950" },
  DIAGNOSTICS: { label: "Diagnostics", icon: "Microscope", color: "text-amber-700 bg-amber-100 dark:text-amber-300 dark:bg-amber-950" },
  PHARMACY: { label: "Pharmacy", icon: "Pill", color: "text-rose-700 bg-rose-100 dark:text-rose-300 dark:bg-rose-950" },
  CHECKOUT: { label: "Checkout", icon: "BadgeCheck", color: "text-teal-700 bg-teal-100 dark:text-teal-300 dark:bg-teal-950" },
};

export const TIME_SLOTS = [
  "09:00 AM", "10:00 AM", "11:00 AM", "12:00 PM",
  "05:00 PM", "06:00 PM", "07:00 PM", "08:00 PM",
];

export const DOCTOR_PHOTOS = Array.from({ length: 10 }, (_, i) => `/images/doctors/doctor-${i + 1}.png`);
export const BLOG_COVERS = Array.from({ length: 4 }, (_, i) => `/images/blog/blog-${i + 1}.png`);

# BDHospital — Hospital Management System 🏥

**Web Engineering Lab (CSE416) Project**

> **Developed by:** Imran Munshi
> **Student ID:** 222-15-6376
> **Department:** Computer Science & Engineering
> **University:** Daffodil International University
> **Course:** Web Engineering Lab — CSE416

---

## 📖 Table of Contents

1. [About The Project](#-about-the-project)
2. [Key Features](#-key-features)
3. [Technology Stack](#-technology-stack)
4. [Architecture Overview](#-architecture-overview)
5. [Getting Started](#-getting-started)
6. [Database Schema](#-database-schema)
7. [REST API Documentation](#-rest-api-documentation)
8. [Project Structure](#-project-structure)
9. [Screenshots](#-screenshots)
10. [Credits](#-credits)

---

## 📌 About The Project

**BDHospital** is a complete redevelopment of a classic Django-based hospital management
system into a modern, production-grade **full-stack web application**. It digitizes the
entire workflow of a multi-specialty hospital — from doctor & patient records to
appointment scheduling — and introduces two flagship capabilities:

- ⭐ **Doctor Review System** — verified star ratings and written reviews from patients,
  with live aggregate ratings on every doctor profile.
- 📡 **Real-Time Patient Tracking** — watch patients move **live** through every hospital
  department (Registration → Triage → Consultation → Diagnostics → Pharmacy → Checkout),
  with queue tokens, vitals, wait-time analytics and a live ward/bed occupancy board.

The application is a single-page style dashboard with seven fully interactive modules,
backed by a REST API and a relational database, with light/dark themes and a fully
responsive mobile-first layout.

---

## ✨ Key Features

### 1. 📊 Hospital Dashboard (Analytics)
- Live KPI cards: doctors on duty, patients checked in today, today's appointments,
  average doctor rating, bed occupancy rate.
- **Appointments-per-day** area chart (last 7 days) and **doctors-by-specialty** pie chart.
- Live hospital flow mini-board with active patient tokens and wait times.
- Top-rated doctors leaderboard and latest patient reviews.
- 24/7 emergency & ambulance banner (national hotlines 999 / 16163).

### 2. 🩺 Doctor Management
- Directory of specialist physicians with AI-generated portrait photos, specialty,
  designation, consultation fee, years of experience and availability.
- Search by name/designation/bio and filter by specialty.
- Full CRUD: add, edit (including photo picker), and safely delete doctors
  (with cascading history cleanup).
- **Doctor profile dialog** with bio, contact info, appointment stats, rating
  distribution and all patient reviews.

### 3. 🧑‍🤝‍🧑 Patient Management
- Patient registry with demographics, blood group, insurance ID and address.
- Search across name, email, phone and blood group.
- Patient profile with complete appointment history, reviews written, and current
  live hospital status.
- One-click **Check-In** that issues a queue token and starts real-time tracking.

### 4. 📅 Appointment Management
- Booking dialog with doctor/patient selectors, date picker and time-slot picker that
  **greys out already-booked slots** for the selected doctor.
- Server-side double-booking prevention (HTTP 409).
- Status workflow: `SCHEDULED → CONFIRMED → COMPLETED` (or `CANCELLED`).
- **"Send to Queue"** action that checks a confirmed patient into the live hospital flow.

### 5. ⭐ Doctor Reviews (NEW — flagship feature)
- Patients publish 1–5 star ratings with written feedback for any doctor.
- Doctor ratings & review counts **recompute automatically** after every change.
- Reviews tab: average score, star-distribution histogram, doctor filter, review wall
  and moderation (delete).
- Reviews appear instantly on doctor cards, profiles and the dashboard.

### 6. 📡 Real-Time Patient Tracking (NEW — flagship feature)
- Six-department live flow board: **Registration → Triage → Consultation →
  Diagnostics → Pharmacy → Checkout**.
- Patients **progress automatically in real time** based on wall-clock time with
  deterministic per-patient stage durations — the board updates itself every 3 seconds.
- Queue tokens (`T-101`, `T-102`, …), priority badges (Normal / Urgent / Emergency with
  pulse animation), per-stage progress bars and total wait times.
- Patient detail dialog: vitals (BP, pulse, temperature, SpO₂), full journey timeline
  with per-stage durations, assigned doctor, and manual **Advance Stage / Complete
  Journey** controls.
- **New Patient Arrival** simulation to check walk-ins into the flow instantly.
- **Ward & Bed Management**: five wards (General, ICU, Emergency, Maternity, Pediatric)
  with photo headers, live occupancy bars and clickable beds — assign a patient,
  discharge & clean, or mark available.

### 7. 📰 Health Library (Blogs)
- Health articles authored by BDHospital doctors with cover images, categories,
  view counters and author cards.
- In-app article reader with typeset paragraphs.
- **Publish Article** dialog (doctor content publishing, as in the original system).

### 8. 🎨 UX & Engineering
- Light / dark theme toggle, fully responsive mobile-first layout with safe touch targets.
- Sticky header navigation + sticky footer (never floats or overlaps content).
- Toast notifications, loading skeletons, empty states, confirm dialogs for destructive
  actions, accessible ARIA labels and keyboard-navigable controls.

---

## 🛠 Technology Stack

| Layer | Technology |
|---|---|
| **Frontend** | Next.js 16 (App Router), React 19, TypeScript 5 |
| **Styling & UI** | Tailwind CSS 4, shadcn/ui (New York), Lucide icons, Framer Motion animations |
| **Server State** | TanStack Query v5 (polling-based live updates) |
| **Backend** | Next.js Route Handlers (REST API, Node runtime) |
| **Validation** | Zod (request schema validation) |
| **Database** | SQLite via Prisma ORM |
| **Charts** | Recharts |
| **Notifications** | Sonner |
| **Theming** | next-themes |

**Why this stack?** It replaces the original Django/Python/Bootstrap stack with a single
unified **TypeScript** codebase for both frontend and backend — fewer languages, type
safety end-to-end, instant startup, and a modern component-driven UI.

---

## 🏗 Architecture Overview

```
┌──────────────────────────────────────────────────────────────┐
│                        BROWSER (Client)                      │
│  Next.js 16 App Router SPA (src/app/page.tsx)                │
│  ├─ 7 modules: Dashboard · Doctors · Patients · Appointments │
│  │             Reviews · Live Tracking · Blogs                │
│  └─ TanStack Query cache + 3s/5s polling for LIVE data       │
└──────────────────────────────┬───────────────────────────────┘
                               │  fetch() — REST (JSON)
┌──────────────────────────────▼───────────────────────────────┐
│                   NEXT.JS API ROUTES (Server)                 │
│  /api/stats        /api/doctors[/id]      /api/patients[/id]  │
│  /api/appointments[/id]  /api/reviews[/id]  /api/tracking[/id]│
│  /api/beds[/id]    /api/blogs[/id]        /api/specialties    │
│                                                              │
│  ├─ Zod request validation & typed error responses           │
│  └─ Tracking simulation engine (time-based stage advance,    │
│     deterministic durations, vitals generation)              │
└──────────────────────────────┬───────────────────────────────┘
                               │  Prisma Client
┌──────────────────────────────▼───────────────────────────────┐
│                  SQLite — db/custom.db                        │
│  Specialty · Doctor · Patient · Appointment · Review          │
│  TrackingRecord · Bed · Blog  (8 models, cascading deletes)   │
└──────────────────────────────────────────────────────────────┘
```

**Real-time tracking approach:** the `/api/tracking` endpoint runs a deterministic
simulation on every request — each active patient's stage progress is computed from the
wall clock and per-record pseudo-random stage durations, and advances are persisted to
the database. The client polls every 3 seconds, producing a genuinely live board that
works on any hosting without WebSocket infrastructure.

---

## 🚀 Getting Started

### Prerequisites
- **Node.js 18+** (or **Bun 1.1+** — fastest option)
- npm / pnpm / bun (any package manager)

### Installation & Run

```bash
# 1. Install dependencies
npm install            # or: bun install

# 2. Generate the Prisma client
npm run db:generate    # or: bun run db:generate

# 3. (Optional) Recreate the database schema
npm run db:push        # or: bun run db:push

# 4. (Optional) Re-seed with realistic demo data
npm run db:seed        # or: bun run db:seed

# 5. Start the development server
npm run dev            # or: bun run dev
```

Then open **http://localhost:3000** in your browser.

> 💡 The repository already ships with a **pre-seeded database** (`db/custom.db`),
> so the app is fully populated on first run. Re-seed any time with `npm run db:seed`
> — it also resets the live tracking board with fresh, actively moving patients.

### Available Scripts

| Script | Description |
|---|---|
| `npm run dev` | Start the Next.js dev server on port 3000 |
| `npm run db:generate` | Generate the Prisma client |
| `npm run db:push` | Push the schema to the SQLite database |
| `npm run db:seed` | Wipe & re-seed realistic demo data |
| `npm run lint` | Run ESLint |
| `npm run build` | Production build |

---

## 🗄 Database Schema

8 models with full referential integrity (cascading deletes where appropriate):

```
Specialty (8)        ──┐
  └─ Doctor (10)       │  doctors belong to one specialty
       │               │
       ├── Appointment (40)  ── Patient (15)
       │       │                    │
       │       └── TrackingRecord  ├── Review
       │           (live flow)     │      └─ (rating 1–5 + comment)
       │                           │
       ├── Blog (4)                └── Bed (20, 5 wards)
       └── Review (22)
```

| Model | Purpose | Key Fields |
|---|---|---|
| `Specialty` | Medical departments | name, description, icon |
| `Doctor` | Physicians | fullName, designation, specialtyId, fee, experienceYears, **rating**, **reviewCount**, photo, isAvailable |
| `Patient` | Registered patients | fullName, age, gender, bloodGroup, phone, insuranceId |
| `Appointment` | Doctor–patient visits | date, timeSlot, reason, status |
| `Review` | ⭐ Doctor reviews | doctorId, patientId, rating (1–5), comment |
| `TrackingRecord` | 📡 Live patient flow | tokenNumber, currentStage, stageEnteredAt, priority, vitals, history (JSON) |
| `Bed` | Ward beds | ward, bedNumber, status, patientId |
| `Blog` | Health articles | title, summary, content, coverImage, views |

---

## 🔌 REST API Documentation

All responses are JSON. Errors: `{ "error": "message" }` with proper HTTP status codes.

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/stats` | Dashboard analytics (KPIs, 7-day chart, specialty distribution) |
| `GET` | `/api/doctors?search=&specialtyId=` | List doctors (with specialty) |
| `POST` | `/api/doctors` | Add a doctor |
| `GET` `PATCH` `DELETE` | `/api/doctors/{id}` | Fetch / update / delete a doctor |
| `GET` | `/api/patients?search=` | List patients |
| `POST` | `/api/patients` | Register a patient |
| `PATCH` `DELETE` | `/api/patients/{id}` | Update / delete a patient |
| `GET` | `/api/appointments?status=&date=&doctorId=&patientId=` | Filterable appointment list |
| `POST` | `/api/appointments` | Book an appointment (**409** on double-booking) |
| `PATCH` `DELETE` | `/api/appointments/{id}` | Change status / edit / delete |
| `GET` | `/api/reviews?doctorId=&patientId=` | Reviews with doctor & patient info |
| `POST` | `/api/reviews` | Publish a review (recomputes doctor rating) |
| `DELETE` | `/api/reviews/{id}` | Delete a review (recomputes rating) |
| `GET` | `/api/tracking` | **LIVE board** — runs time-based simulation, returns records + stage counts + queue stats |
| `POST` | `/api/tracking` | Check a patient in (issues next token `T-1xx`) |
| `PATCH` | `/api/tracking/{id}` | `{ "action": "advance" \| "complete" }` |
| `GET` | `/api/beds` | Beds + per-ward occupancy summary |
| `PATCH` | `/api/beds/{id}` | Assign / discharge / clean a bed |
| `GET` | `/api/blogs` · `/api/blogs/{id}` | List articles (view counter increments) |
| `POST` `DELETE` | `/api/blogs` · `/api/blogs/{id}` | Publish / delete an article |
| `GET` | `/api/specialties` | Specialties with doctor counts |

### Example — publish a review
```bash
curl -X POST http://localhost:3000/api/reviews \
  -H "Content-Type: application/json" \
  -d '{"doctorId":1,"patientId":3,"rating":5,"comment":"Excellent care!"}'
```

### Example — check a patient into the live queue
```bash
curl -X POST http://localhost:3000/api/tracking \
  -H "Content-Type: application/json" \
  -d '{"patientId":5,"priority":"URGENT"}'
# → { "record": { "tokenNumber": "T-111", "currentStage": "REGISTRATION", ... } }
```

---

## 📁 Project Structure

```
BDHospital/
├── db/
│   └── custom.db                 # SQLite database (pre-seeded)
├── prisma/
│   ├── schema.prisma             # 8-model database schema
│   └── seed.mjs                  # Demo data seeder (idempotent)
├── public/
│   └── images/                   # 18 AI-generated real images
│       ├── hero-hospital.png     # Hospital building (hero banner)
│       ├── ambulance.png         # Emergency banner
│       ├── doctors/              # 10 doctor portraits
│       ├── wards/                # ICU & General ward interiors
│       └── blog/                 # 4 blog cover images
├── src/
│   ├── app/
│   │   ├── layout.tsx            # Root layout + theme provider
│   │   ├── page.tsx              # Main SPA (7 tab modules)
│   │   ├── globals.css           # Tailwind theme tokens
│   │   └── api/                  # REST API route handlers (11 groups)
│   │       ├── stats/  doctors/  patients/  appointments/
│   │       ├── reviews/  tracking/  beds/  blogs/  specialties/
│   ├── components/
│   │   ├── bdhospital/           # Feature modules
│   │   │   ├── header.tsx  hero.tsx  footer.tsx  shared.tsx
│   │   │   ├── dashboard.tsx  doctors.tsx  patients.tsx
│   │   │   ├── appointments.tsx  reviews.tsx  tracking.tsx  blogs.tsx
│   │   └── ui/                   # shadcn/ui component library
│   └── lib/
│       ├── api.ts                # Typed API client + shared types
│       ├── db.ts                 # Prisma client singleton
│       ├── tracking.ts           # Real-time simulation engine
│       ├── dates.ts  validation.ts  utils.ts
└── package.json
```

---

## 🖼 Screenshots

| Module | Preview |
|---|---|
| Dashboard with hero & analytics | `public/images/hero-hospital.png` |
| Live patient flow board | Run the app → **Live Tracking** tab |
| Doctor directory | Run the app → **Doctors** tab |
| Ward & bed management | Run the app → **Live Tracking** tab (bottom) |

All 18 photos used across the app (hospital, doctors, wards, ambulance, blog covers)
are AI-generated and included in `public/images/`.

---

## 🙏 Credits

- **Developer:** Imran Munshi — ID **222-15-6376**, Department of CSE,
  Daffodil International University.
- **Course:** Web Engineering Lab (**CSE416**).
- **Original project:** Redeveloped from a Django "Hospital Management" system into a
  modern Next.js full-stack application with new features (doctor reviews, real-time
  patient tracking, bed management, analytics dashboard).
- **Built with:** Next.js, React, TypeScript, Tailwind CSS, shadcn/ui, Prisma,
  TanStack Query, Recharts, Framer Motion, Lucide.

---

© 2025 BDHospital — Web Engineering Lab (CSE416) Project. All rights reserved.
